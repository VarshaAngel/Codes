package com.wipro.bank.acc;

public class RDAccount extends Account{

	public RDAccount(int tenure, float principal){
		super();
		this.tenure = tenure;
		this.principal = principal;
	}
	
	public float calculateAmountDeposited(){
		
		float totalAmount = principal*tenure*12;
		return totalAmount;
		
	}
	
	public float calculateInterest(){
		//P * (((1+r/n)^nt) - 1)
		float totalInterest = 0;
		float P = principal;
		float n = 4;
		float r = rateOfInterest/100;
		int monthRemaining = 60;
		 while(monthRemaining>0){
			 float  t = monthRemaining/12.0f;
			 totalInterest = (float) (totalInterest + (P * ((Math.pow((1+r/n), (n*t))) - 1)));
			 System.out.println(totalInterest);
			 monthRemaining--;
		}
		
		return totalInterest;
		
	}
		
}
