package com.wipro.video.bean;

import java.util.Date;

public class VideoBean {

	String videoID;
	String videoName;
	PublisherBean publisher;
	char videoType;
	double cost;
	Date dateOfPublish;
	
	public String getVideoID() {
		return videoID;
	}
	public void setVideoID(String videoID) {
		this.videoID = videoID;
	}
	public String getVideoName() {
		return videoName;
	}
	public void setVideoName(String videoName) {
		this.videoName = videoName;
	}
	public PublisherBean getPublisher() {
		return publisher;
	}
	public void setPublisher(PublisherBean publisher) {
		this.publisher = publisher;
	}
	public char getVideoType() {
		return videoType;
	}
	public void setVideoType(char videoType) {
		this.videoType = videoType;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	public Date getDateOfPublish() {
		return dateOfPublish;
	}
	public void setDateOfPublish(Date dateOfPublish) {
		this.dateOfPublish = dateOfPublish;
	}

}
