package com.wipro.video.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.video.bean.PublisherBean;
import com.wipro.video.bean.VideoBean;
import com.wipro.video.service.Administrator;

/**
 * Servlet implementation class MainServlet
 */
@WebServlet("/MainServlet")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public MainServlet() {
        // TODO Auto-generated constructor stub
    	super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
	    String operation = request.getParameter("operation");
	    
		if(operation.equals("AddVideo")){
			
			String result = addVideo(request);
			
			if(result.equals("SUCCESS")){
				response.sendRedirect("Menu.html");
			}else if(result.equals("FAILURE")){
				response.sendRedirect("Failure.html");
			}else {
				response.sendRedirect("Invalid.html");
			}
		}
		else if(operation.equals("Delete")){
			int result = deleteVideo(request.getParameter("publisherName"));
			if(result == 0){
			     out.println("There are no books with the given publisher name");
			}else {
			     out.println(result+" videos were deleted");
			}
		}
		
	}
	public String addVideo(HttpServletRequest request){
		VideoBean videoBean = new VideoBean();
		
		System.out.println("hi");
		videoBean.setVideoID(request.getParameter("videoID"));
		videoBean.setVideoName(request.getParameter("videoName"));
		videoBean.setVideoType(request.getParameter("videoType").charAt(0));
		PublisherBean publisherBean = new PublisherBean();
		publisherBean.setPublisherName(request.getParameter("publisher"));
		videoBean.setPublisher(publisherBean);
		videoBean.setCost(Double.parseDouble(request.getParameter("cost")));
		videoBean.setDateOfPublish(new Date(request.getParameter("dateOfPublish")));
		
		return new Administrator().addVideo(videoBean);
	}
	public int deleteVideo(String id){
		return new Administrator().deleteVideo(id);
		
	}
}


