package com.wipro.video.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.wipro.video.bean.PublisherBean;
import com.wipro.video.util.DBUtil;

public class PublisherDAO {

	PublisherBean getPublisher(int publisherCode){
		PublisherBean publisherBean = new PublisherBean();
		try{
			Connection conn = DBUtil.getDBConnection();
			String query = "select * from Publisher_Tbl where Publisher_code = ?";
			PreparedStatement pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, publisherCode);
			ResultSet result = pstmt.executeQuery();
			while(result.next()){
				String name = result.getString(2);
				String addr = result.getString(3);
				publisherBean.setPublisherName(name);
				publisherBean.setAddress(addr);
			}
			return publisherBean;
		}catch(Exception e){
			System.out.println(e.toString());
			return null;
		}
		
	}
	PublisherBean getPublisher (String publisherName){
		PublisherBean publisherBean = new PublisherBean();
		try{
			Connection conn = DBUtil.getDBConnection();
			String query = "select * from Publisher_Tbl where Publisher_name = ?";
			PreparedStatement pstmt = conn.prepareStatement(query);
		    pstmt.setString(2, publisherName);
		    ResultSet result = pstmt.executeQuery();
		    while(result.next()){
		    	int code = result.getInt(1);
		    	String addr = result.getString(3);
		    	publisherBean.setPublisherCode(code);
		    	publisherBean.setAddress(addr);
		    }
		    return publisherBean;
		}catch(Exception e){
			System.out.println(e.toString());
			return null;
		}
		
	}
}
