package com.wipro.video.dao;

import java.lang.reflect.GenericArrayType;
import java.sql.Connection;
import java.sql.PreparedStatement;

import com.wipro.video.bean.PublisherBean;
import com.wipro.video.bean.VideoBean;
import com.wipro.video.util.DBUtil;

public class VideoDAO {

	public int deleteVideo(String publisherName){
	      int deletedVideos = 0;
	      try{
	    	  Connection conn = DBUtil.getDBConnection();
	    	  PublisherBean publisherBean = new PublisherDAO().getPublisher(publisherName);
	    	  String query = "delete * from Video_Tbl where Publisher_code = ?";
	    	  PreparedStatement pstmt = conn.prepareStatement(query);
	    	  pstmt.setInt(1, publisherBean.getPublisherCode());
	    	  deletedVideos = pstmt.executeUpdate();
	      }catch(Exception e){
	    	  System.out.println(e.toString());
	      }
		return deletedVideos;
	}
    public int createVideo(VideoBean videoBean){
    	int insertion = 0;
    	try{
    		Connection conn = DBUtil.getDBConnection();
    		String query = "insert into Video_Tbl(?,?,?,?,?,?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, videoBean.getVideoID());
            pstmt.setString(2, videoBean.getVideoName());
            pstmt.setString(3, Character.toString(videoBean.getVideoType()));
            PublisherBean publisherBean = new PublisherBean();
            String name = publisherBean.getPublisherName();
            PublisherDAO publisherDao = new PublisherDAO();
            publisherBean = publisherDao.getPublisher(name);
            pstmt.setInt(4, publisherBean.getPublisherCode());
            pstmt.setDouble(5, videoBean.getCost());
            pstmt.setDate(6, new java.sql.Date(videoBean.getDateOfPublish().getTime()));
            if(pstmt.executeUpdate() == 6){
            	insertion = 1;
            }
    	}catch(Exception e){
    		System.out.println(e.toString());
    		insertion =0;
    	}
		return insertion;
		
	}
}
