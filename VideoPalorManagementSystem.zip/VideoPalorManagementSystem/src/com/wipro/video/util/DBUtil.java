package com.wipro.video.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {
	public static Connection getDBConnection(){
		
		Connection connection = null;
		try{
			Class.forName("Oracle.Jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@orcl.rmkec.ac.in:1521:orcl","scott", "tiger");
		}catch(Exception e){
			System.out.println(e.toString());
		}
		return connection;
	
	}
}

