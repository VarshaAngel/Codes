package com.wipro.video.service;

import com.wipro.video.bean.PublisherBean;
import com.wipro.video.bean.VideoBean;
import com.wipro.video.dao.VideoDAO;

public class Administrator {

	public int deleteVideo(String publisherName){
		VideoDAO videoDao = new VideoDAO();
		int numberOfVideos = videoDao.deleteVideo(publisherName);
		return numberOfVideos;
		
	}
	public String addVideo(VideoBean videoBean){
		if(videoBean!=null){
			return "INVALID";
		}
		if(videoBean.getVideoName() == " "){
			return "INVALID";
		}
		if(videoBean.getVideoID() == " "){
			return "INVALID";
		}
		if(videoBean.getVideoType() == ' '){
			return "INVALID";
		}
		if(videoBean.getVideoType()!='G' || videoBean.getVideoType()!='T'){
			return "INVALID";
		}
		if(videoBean.getCost()==0){
			return "INVALID";
		}
		if(new PublisherBean().getPublisherName()==" "){
			return "INVALID";
		}
		VideoDAO videoDao = new VideoDAO();
		int result = videoDao.createVideo(videoBean);
		if(result == 0){
			return "FAILURE";
		}else {
			return "SUCCESS";
		}
		
	}
}
