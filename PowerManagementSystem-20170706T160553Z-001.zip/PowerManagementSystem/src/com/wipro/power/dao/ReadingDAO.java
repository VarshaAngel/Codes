package com.wipro.power.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.wipro.power.bean.ReadingBean;
import com.wipro.power.util.DBUtil;

public class ReadingDAO {

	public String createReading(ReadingBean readingBean){
		 
		String s = null;
		try{
			Connection con = DBUtil.getDBConnection();
			String query = "insert into READINGS_TBL values(serialNO, assetID, type, presentReading, pastReading, billMonth, billYear, unitsUsed, amount) ";
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setInt(1,generateSerialNo());
			pstmt.setString(2,readingBean.getAssetID());
			pstmt.setString(3,readingBean.getType());
			pstmt.setInt(4,readingBean.getPresentReading());
			pstmt.setInt(5,readingBean.getPastReading());
			pstmt.setString(6,readingBean.getBillMonth());
			pstmt.setString(7, readingBean.getBillYear());
			pstmt.setInt(8, readingBean.getUnitsUsed());
			pstmt.setFloat(9, readingBean.getAmount());
			System.out.println(pstmt.executeUpdate());
			if(pstmt.executeUpdate()==9)
			{   
				
			    s = "SUCCESS";
			}
			
		}catch(Exception e)
		{
			System.out.println(e.toString());
			s = "FAIL";
		}
		return s;
	}
	
	public int generateSerialNo(){
		
		int id = 0;
		try{
			Connection con = DBUtil.getDBConnection();
			String query = "select SERIALNO_SEQ.nextval from dual";
			PreparedStatement pstmt = con.prepareStatement(query);
			ResultSet result = pstmt.executeQuery();
			if(result.next())
			{
				id = result.getInt(1);
			}
			return id;
		}catch(Exception e){
			System.out.println(e.toString());
			return id;
		}
	}
 
	public ArrayList<ReadingBean> viewAllBillsByMonth(String month,String year){
		
		ArrayList<ReadingBean> matchingRecords = new ArrayList<ReadingBean>();
		 
		try{
			  Connection con = DBUtil.getDBConnection();
			  String query = "select * from READINGS_TBL where billMonth = month and billYear = year";
			  PreparedStatement pstmt = con.prepareStatement(query);
			  ResultSet result = pstmt.executeQuery();
			  while(result.next()){
			  matchingRecords.add((ReadingBean) result);
			  }
			  return matchingRecords;
		}catch(Exception e){
		System.out.println(e.toString());
		return null;
		}
	}
}
