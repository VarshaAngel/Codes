package com.wipro.power.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.wipro.power.bean.PowerRateBean;
import com.wipro.power.util.DBUtil;

public class PowerRateDAO {

	public PowerRateBean findRateByType(String type){
		PowerRateBean pbean = new PowerRateBean();
		try{
			Connection con = DBUtil.getDBConnection();
			
			PreparedStatement pstmt = con.prepareStatement("select * from POWER_RATE_TBL where type = ?");
			pstmt.setString(1,type);
			ResultSet result = pstmt.executeQuery();
			while(result.next()){
				
				String tp=result.getString(1);
				int s1=result.getInt(2);
				int s2=result.getInt(3);
				int s3=result.getInt(4);
				float srate1=result.getFloat(5);
				float srate2=result.getFloat(6);
				float srate3=result.getFloat(7);
				System.out.println(tp+" "+srate1+" "+srate2+" "+srate3);
				pbean.setType(tp);
				pbean.setSlab1(s1);
				pbean.setSlab2(s2);
				pbean.setSlab3(s3);
				pbean.setSlabRate1(srate1);
				pbean.setSlabRate2(srate2);
				pbean.setSlabRate3(srate3);
			}
			return pbean;
		}catch(Exception e)
		{
			System.out.println(e.toString());
			return null;
		}
	}
}

