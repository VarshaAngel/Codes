package com.wipro.power.bean;

public class ReadingBean {

	private int serialNo;
	private String assetID;
	private String type;
	private int presentReading;
	private int pastReading;
	private String billMonth;
	private String billYear;
	private int unitsUsed;
	private float amount;
	public char[] getAmount;
	public int getSerialNo() {
		return serialNo;
	}
	public String getAssetID() {
		return assetID;
	}
	public String getType() {
		return type;
	}
	public int getPresentReading() {
		return presentReading;
	}
	public int getPastReading() {
		return pastReading;
	}
	public String getBillMonth() {
		return billMonth;
	}
	public String getBillYear() {
		return billYear;
	}
	public int getUnitsUsed() {
		return unitsUsed;
	}
	public float getAmount() {
		return amount;
	}
	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}
	public void setAssetID(String assetID) {
		this.assetID = assetID;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setPresentReading(int presentReading) {
		this.presentReading = presentReading;
	}
	public void setPastReading(int pastReading) {
		this.pastReading = pastReading;
	}
	public void setBillMonth(String billMonth) {
		this.billMonth = billMonth;
	}
	public void setBillYear(String billYear) {
		this.billYear = billYear;
	}
	public void setUnitsUsed(int unitsUsed) {
		this.unitsUsed = unitsUsed;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	
}
