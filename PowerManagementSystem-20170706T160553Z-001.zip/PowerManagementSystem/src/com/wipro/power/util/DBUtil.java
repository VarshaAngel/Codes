package com.wipro.power.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {

	public static Connection getDBConnection(){
		
		Connection conn = null;
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("Jdbc:Oracle:thin:@orcl.rmk.ac.in:1521:orcl","scott", "tiger");
			
		}catch(Exception e){
			System.out.println(e.toString());return null;
		}
		return conn;
	}
}
