package com.wipro.power.service;

import java.sql.Connection;

import java.util.ArrayList;

import com.wipro.power.dao.PowerRateDAO;
import com.wipro.power.dao.ReadingDAO;
import com.wipro.power.util.DBUtil;
import com.wipro.power.bean.PowerRateBean;
import com.wipro.power.bean.ReadingBean;

public class PowerMain {

	public static void main(String[] args) {
		
		ReadingBean readingBean = new ReadingBean();
readingBean.setAssetID("HO1122");
readingBean.setPresentReading(155);
readingBean.setPastReading(100);
readingBean.setType("House");
readingBean.setBillMonth("Feb");
readingBean.setBillYear("2015");
String result = new PowerMain().generateBill(readingBean);
System.out.println(result);
ArrayList<ReadingBean> bills=new PowerMain().viewAllBills("Feb","2015");
if(bills!=null){
		for(ReadingBean reading: bills)
		{
		System.out.println(reading.getSerialNo());
        System.out.println(reading.getAmount());
        }
		}
}

		 
	
	
	public String generateBill(ReadingBean readingBean){
		
		if(readingBean == null )
			return "INVALID";
		if(readingBean.getPastReading() > readingBean.getPresentReading())
			return "INVALID";
		
		
		if(!((readingBean.getType().equals("House")) || (readingBean.getType().equals("Shop")) || (readingBean.getType().equals("Mall"))))
				return "INVALID TYPE";
		
		
		int unitsUsed= readingBean.getPresentReading() - readingBean.getPastReading();
		
		readingBean.setUnitsUsed(unitsUsed);
		float amount = calculateAmount(unitsUsed, readingBean.getType());
		readingBean.setAmount(amount);
		ReadingDAO values = new ReadingDAO();
		values.createReading(readingBean);
		if(values.equals("FAIL"))
		{
			return "FAIL";
		}
		else
		{
			return "BILL AMOUNT: "+amount;
		}
	}
	
	public float calculateAmount(int unitsUsed, String type){
		 
	    float amount = 0;
	    try{
	    	PowerRateBean rates = new PowerRateBean();
	    	PowerRateDAO values = new PowerRateDAO();
	    	rates = values.findRateByType(type);
	    	int slab1units = rates.getSlab1();
	    	int slab2units = rates.getSlab2();
	    	int slab3units = rates.getSlab3();
	    	float slabrate1 = rates.getSlabRate1();
	    	float slabrate2 = rates.getSlabRate2();
	    	float slabrate3 = rates.getSlabRate3();
	    	if(unitsUsed<25)
	    	{
	    		amount = unitsUsed*slabrate1;
	    	}
	    	else if(unitsUsed>=25 && unitsUsed <50)
	    	{
	    		amount = 25*slabrate1 +((unitsUsed-slab2units)* slabrate2);
	    	}
	    	else if(unitsUsed>=50)
	    	{
	    		amount = 25*slabrate1 + 25*slabrate2 + ((unitsUsed-slab3units)*slabrate3);
	    	}
	    }catch(Exception e){
		    System.out.println(e.toString());
	    }
		return amount;
	}
	
	public ArrayList<ReadingBean> viewAllBills(String month,String year){
	   
		try{
			ReadingDAO record1 = new ReadingDAO();
         	return record1.viewAllBillsByMonth(month, year);

		}catch(Exception e){
			System.out.println(e.toString());
			return null;
		}
		
	}
	
}
