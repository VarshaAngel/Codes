//
//  CollectionViewCell.swift
//  DemoCollectionView
//
//  Created by cse on 02/03/17.
//  Copyright © 2017 RMK. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var numberLabel: UILabel!
    
    
}
